// Wszystkie pytania z folderów pytania
const allQuestions = [
    // WOS
    ...wosQuestions,
    // Geografia  
    ...geografiaQuestions,
    // Informatyka
    ...informatykaQuestions,
    // Chemia
    ...chemiaQuestions,
    // Historia
    ...historiaQuestions,
    // Sport
    ...sportQuestions,
    // Film
    ...filmQuestions,
    // Literatura
    ...literaturaQuestions,
    // Kuchnia
    ...kuchniaQuestions,
    // Mechanika
    ...mechanikaQuestions,
    // Motoryzacja
    ...motoryzacjaQuestions,
    // Wiedza ogólna
    ...wiedzaOgolnaQuestions,
    // Elektryka
    ...elektrykaQuestions,
    // Polityka
    ...politykaQuestions,
    // Ekonomia
    ...ekonomiaQuestions,
    // Biologia
    ...biologiaQuestions,
    // Muzyka
    ...muzykaQuestions,
    // Sztuka
    ...sztukaQuestions
];
